package com.example.myapp.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.myapp.R;
import com.example.myapp.model.User;
import com.example.myapp.util.Retrofit2.APIUtils;
import com.example.myapp.util.Retrofit2.DataClient;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddPostActivity extends AppCompatActivity {
    RadioGroup radioGroupCategory;
    RadioButton radioButtonCategory;
    ImageView imgAddPost;
    EditText edtAddPostTitle, edtAddPostPrice,edtAddPostDescription,edtAddPostContact;
    Button btnAddPostSubmit;
    int Request_Code_UpLoad_PostImage = 111;
    String realpathaddpost = "";
    ArrayList <User> arraylistUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);

        //
        imgAddPost = findViewById(R.id.img_add_post);
        edtAddPostTitle = findViewById(R.id.edt_add_post_title);
        edtAddPostPrice = findViewById(R.id.edt_add_post_price);
        edtAddPostDescription = findViewById(R.id.edt_add_post_description);
        edtAddPostContact = findViewById(R.id.edt_add_post_contact);
        btnAddPostSubmit =findViewById(R.id.btn_add_post_submit);
        radioGroupCategory = findViewById(R.id.radio_group_category);

        //
        imgAddPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                askPermissionAndReadFile();
            }
        });
        btnAddPostSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //AddPostImage = imgAddPost;
                Intent intent = getIntent();
                arraylistUser = intent.getParcelableArrayListExtra("account");
                final String AddPostUserId = arraylistUser.get(0).getUserId();
                final int AddPostCategoryId = checkButton(radioGroupCategory);
                final String AddPostTitle = edtAddPostTitle.getText().toString();
                final String AddPostPrice = edtAddPostPrice.getText().toString();
                final String AddPostDescription = edtAddPostDescription.getText().toString();
                final String AddPostContact = edtAddPostContact.getText().toString();

                if(realpathaddpost.length() > 0)
                {
                    if (AddPostTitle.length()>0 && AddPostPrice.length()>0 && AddPostDescription.length() >0 && AddPostContact.length() >0)
                    {
                        File file = new File (realpathaddpost);
                        String file_path = file.getAbsolutePath();
                        String[] arrayFileName = file_path.split("\\.");

                        file_path = arrayFileName[0]+ System.currentTimeMillis() +"."+arrayFileName[1];
//                Log.d("url",file_path);
                        RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"),file);

                        MultipartBody.Part body = MultipartBody.Part.createFormData("uploaded_file",file_path,requestBody);

                        DataClient dataClient = APIUtils.getData();
                        retrofit2.Call <String> callback = dataClient.UploadImagePost(body);
                        callback.enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                if(response != null)
                                {
                                    String message = response.body();
//                            Log.d("urlImage",message);
                                    if(message.length()>0)
                                    {
                                        DataClient insertPost = APIUtils.getData();
                                        retrofit2.Call<String> callback = insertPost.InsertPost(Integer.parseInt(AddPostUserId),AddPostCategoryId,AddPostTitle,Integer.parseInt(AddPostPrice),AddPostDescription,AddPostContact,APIUtils.Base_Url +"imagePost/"+message);
                                        callback.enqueue(new Callback<String>() {
                                            @Override
                                            public void onResponse(Call<String> call, Response<String> response) {
                                                String result = response.body();
                                                Log.d("result",result);
                                                if (result.equals("Success"))
                                                {
                                                    Toast.makeText(AddPostActivity.this, "Đăng thành công", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }
                                            }

                                            @Override
                                            public void onFailure(Call<String> call, Throwable t) {

                                            }
                                        });
                                    }
                                }
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                                Log.d("erroAddPost",t.getMessage());
                            }
                        });
                    }
                    else {
                        Toast.makeText(AddPostActivity.this, "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AddPostActivity.this, "Bạn phải chọn hình ảnh đăng bán", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == Request_Code_UpLoad_PostImage && resultCode == RESULT_OK && data!=null) {

            Uri uri = data.getData();
            realpathaddpost = getRealPathFromURI(uri);
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgAddPost.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public String getRealPathFromURI (Uri contentUri) {
        String path = null;
        String[] proj = { MediaStore.MediaColumns.DATA };
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            path = cursor.getString(column_index);
        }
        cursor.close();
        return path;
    }

    public  boolean isStoragePermissionGranted(int requestId, String permissionName) {
        if (android.os.Build.VERSION.SDK_INT >= 23) {

            // Kiểm tra quyền
            int permission = ActivityCompat.checkSelfPermission(this, permissionName);


            if (permission != PackageManager.PERMISSION_GRANTED) {

                // Nếu không có quyền, cần nhắc người dùng cho phép.
                this.requestPermissions(
                        new String[]{permissionName},
                        requestId
                );
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && requestCode == Request_Code_UpLoad_PostImage){
            readFile();
            Log.v("ISPERMISSION","Permission: "+permissions[0]+ "was "+grantResults[0]);
            //resume tasks needing this permission
        }
    }


    private void askPermissionAndReadFile() {
        boolean canRead = this.isStoragePermissionGranted(Request_Code_UpLoad_PostImage,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        //
        if (canRead) {
            this.readFile();
        }
    }

    private void readFile() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,Request_Code_UpLoad_PostImage);
    }

    public int checkButton(View v)
    {
        int radioId = radioGroupCategory.getCheckedRadioButtonId();
        radioButtonCategory = findViewById(radioId);

        if (radioButtonCategory.getText().equals("Sách"))
        {
            return 1;
        }
        else if(radioButtonCategory.getText().equals("Quần áo"))
        {
            return 2;
        }
        else {
                return 3;
        }
    }
}
