package com.example.myapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.myapp.R;
import com.example.myapp.model.User;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class InforUserActivity extends AppCompatActivity {
    Toolbar toolbarUser;
    CircleImageView avtInfoUser;
    TextView txtUsername,txtPhone,txtEmail;
    ArrayList<User> arraylistUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infor_user);

        Intent intent = getIntent();
        arraylistUser = intent.getParcelableArrayListExtra("arrayListUser");
        Log.d("infoUser",arraylistUser.get(0).getUserImage());

        toolbarUser = findViewById(R.id.toolbar_infoUser);
        txtUsername = findViewById(R.id.txt_infoUser_username);
        txtPhone = findViewById(R.id.txt_infoUser_Phone);
        txtEmail = findViewById(R.id.txt_infoUser_Email);
        avtInfoUser = findViewById(R.id.avt_info_user);

        //
        ActionBar();
        //
        txtUsername.setText(arraylistUser.get(0).getUsername());
        txtPhone.setText(arraylistUser.get(0).getPhone());
        txtEmail.setText(arraylistUser.get(0).getEmail());
        Picasso.with(getApplicationContext()).load(arraylistUser.get(0).getUserImage())
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.account)
                .into(avtInfoUser);
    }

    private void ActionBar() {
        setSupportActionBar(toolbarUser);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarUser.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
