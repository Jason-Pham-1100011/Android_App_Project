package com.example.myapp.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.myapp.R;
import com.example.myapp.model.User;
import com.example.myapp.util.Retrofit2.APIUtils;
import com.example.myapp.util.Retrofit2.DataClient;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    LinearLayout myLayout;
    Button btnLogin,btnSignUp;
    AnimationDrawable animationDrawable;
    TextInputEditText edtUsername, edtPassword;
    String username,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Nạp giá trị cho view
        myLayout = findViewById(R.id.login_layout);
        btnLogin = findViewById(R.id.btn_login);
        btnSignUp = findViewById(R.id.btn_register);
        edtUsername = findViewById(R.id.edt_login_username);
        edtPassword = findViewById(R.id.edt_login_password);

        // Hiệu ứng chuyển màu background
        animationDrawable = (AnimationDrawable) myLayout.getBackground();
        animationDrawable.setEnterFadeDuration(4500);
        animationDrawable.setExitFadeDuration(4500);
        animationDrawable.start();

        //event
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username =  edtUsername.getText().toString();
                password = edtPassword.getText().toString();
                Log.d("account",username);
                Log.d("account",password);

                if(edtUsername.length()>0 && edtPassword.length()>0)
                {
                    DataClient dataClient = APIUtils.getData();
                    Call<List<User>> callback = dataClient.Logindata(username,password);
                    callback.enqueue(new Callback<List<User>>() {
                        @Override
                        public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                            ArrayList<User> arraylistUser = (ArrayList<User>) response.body();
                            if (arraylistUser.size()>0)
                            {
                                Log.d("account",arraylistUser.get(0).getUsername());
                                Log.d("account",arraylistUser.get(0).getPassword());
                                Log.d("account",arraylistUser.get(0).getUserImage());
                                Intent intent = new Intent(Login.this,MainActivity.class);
                                intent.putExtra("arrayListUser",arraylistUser);
                                startActivity(intent);
                            }

                        }

                        @Override
                        public void onFailure(Call<List<User>> call, Throwable t) {
                            Toast.makeText(Login.this, "Không có tài khoản này", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else {
                    Toast.makeText(Login.this, "Vui lòng nhập đầy đủ username và password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this,SignUpActivity.class);
                startActivity(intent);
            }
        });

    }
}
