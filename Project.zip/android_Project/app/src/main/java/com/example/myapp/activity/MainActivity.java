package com.example.myapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.R;
import com.example.myapp.adapter.CategoryAdapter;
import com.example.myapp.adapter.PostAdapter;
import com.example.myapp.model.Category;
import com.example.myapp.model.Post;
import com.example.myapp.model.User;
import com.example.myapp.util.Server;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    Toolbar tb1;
    RecyclerView recyclerView;
    NavigationView navigationView;
    ListView listView;
    DrawerLayout drawerLayout;
    CircleImageView avatarUser;
    ArrayList<Category> arraylistCategory;
    CategoryAdapter categoryAdapter;
    int category_id = 0;
    String category_title = "";
    String category_image = "";
    ArrayList<Post> arraylistPost;
    ArrayList <User> arraylistUser;
    PostAdapter postAdapter;
    int post_id,user_post_id,category_post_id,post_price;
    String post_title, post_descripe,post_contact,post_image;
    Button btnSearch ;
    //SearchView searchView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        arraylistUser = intent.getParcelableArrayListExtra("arrayListUser");
        Log.d("infoMain",arraylistUser.get(0).getUserImage());

        // Tạo sự kiện cho các view
        tb1 = findViewById(R.id.toolbar1);
        recyclerView = findViewById(R.id.activity_recyclerView);
        navigationView = findViewById(R.id.activity_navigationView);
        listView = findViewById(R.id.activity_listView_mainGreen);
        drawerLayout = findViewById(R.id.activity_drawerLayout);
        avatarUser = findViewById(R.id.avatarUser_Main);
        btnSearch = findViewById(R.id.btn_search);
        //searchView = findViewById(R.id.simpleSearchView);

        Picasso.with(getApplicationContext()).load(arraylistUser.get(0).getUserImage())
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.account)
                .into(avatarUser);

        //
        arraylistCategory = new ArrayList<>();
        categoryAdapter = new CategoryAdapter(arraylistCategory,getApplicationContext());
        listView.setAdapter(categoryAdapter);

        //
        arraylistPost = new ArrayList<>();
        postAdapter = new PostAdapter(getApplicationContext(),arraylistPost);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        recyclerView.setAdapter(postAdapter);

        //Bắt sự kiện cho thanh toolbar
        actionBar();
        //
        getData_category();
        //
        getData_Post();
        //
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,SearchActivity.class);
                startActivity(intent);
            }
        });

        avatarUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,InforUserActivity.class);
                intent.putExtra("arrayListUser",arraylistUser);
                startActivity(intent);
            }
        });

        //
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                switch (position)
                {
                    case 0:
                        finish();
                        startActivity(getIntent());
                        drawerLayout.closeDrawer(GravityCompat.START);
//                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent = new Intent(MainActivity.this,PostByCategoryActivity.class);
                        intent.putExtra("category_title",arraylistCategory.get(position).getCategory_title());
                        intent.putExtra("category_id",arraylistCategory.get(position).getId());
                        startActivity(intent);
                        break;

                    case 2:
                        Intent intent2 = new Intent(MainActivity.this,PostByCategoryActivity.class);
                        intent2.putExtra("category_title",arraylistCategory.get(position).getCategory_title());
                        intent2.putExtra("category_id",arraylistCategory.get(position).getId());
                        startActivity(intent2);
                        break;

                    case 3:
                        Intent intent3 = new Intent(MainActivity.this,PostByCategoryActivity.class);
                        intent3.putExtra("category_title",arraylistCategory.get(position).getCategory_title());
                        intent3.putExtra("category_id",arraylistCategory.get(position).getId());
                        startActivity(intent3);
                        break;
                    case 4:
                        Intent intentAddPost = new Intent(MainActivity.this,AddPostActivity.class);
                        intentAddPost.putExtra("account",arraylistUser);
                        startActivity(intentAddPost);
                        break;
                    case 5:
                        finish();
                        break;
                }
            }
        });
    }

    private void getData_category() {
        arraylistCategory.add(0,new Category(0,"Trang chủ","house"));
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Server.url_category, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if(response != null)
                {
                    for (int i =0; i < response.length();i++)
                    {
                        try {
                            JSONObject jsonObject = response.getJSONObject(i);
                            category_id = jsonObject.getInt("category_id");
                            category_title = jsonObject.getString("category_title");
                            category_image = jsonObject.getString("category_image");
                            arraylistCategory.add(new Category(category_id,category_title,category_image));
                            categoryAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    arraylistCategory.add(4,new Category(0,"Bán","sell"));
                    arraylistCategory.add(5,new Category(0,"Đăng xuất","login"));
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Failconnect",Server.url_category);
                Log.d("Failreason",error.toString());
                Toast.makeText(MainActivity.this,Server.url_category , Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonArrayRequest);
    }

    private void getData_Post(){

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Server.url_post, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if(response != null)
                {
                    for (int i =0; i < response.length();i++)
                    {
                        try {
                            JSONObject jsonObject = response.getJSONObject(i);
                            post_id = jsonObject.getInt("post_id");
                            user_post_id = jsonObject.getInt("user_id");
                            category_post_id = jsonObject.getInt("category_id");
                            post_title = jsonObject.getString("post_title");
                            post_price = jsonObject.getInt("post_price");
                            post_descripe = jsonObject.getString("post_descripe");
                            post_contact= jsonObject.getString("post_contact");
                            post_image= jsonObject.getString("post_image");

                            arraylistPost.add(new Post(post_id,user_post_id,category_post_id,post_title,post_price,post_descripe,post_contact,post_image));
                            postAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Failconnect",Server.url_post);
                Log.d("Failreason",error.toString());
                Toast.makeText(MainActivity.this,Server.url_post , Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonArrayRequest);

    }

    // Hàm bắt sự kiện cho thanh toolbar
    private void actionBar()
    {
        setSupportActionBar(tb1);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tb1.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size); // Tạo nút mở menu
        tb1.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START); //Mở thanh menu trái khi click vào nút menu
            }
        });
    }
}
