package com.example.myapp.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.R;
import com.example.myapp.adapter.PostByCategoryAdapter;
import com.example.myapp.model.Post;
import com.example.myapp.util.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PostByCategoryActivity extends AppCompatActivity {

    Toolbar tbarPostByCategory;
    ListView listViewPostByCategory;
    PostByCategoryAdapter postByCategoryAdapter;
    ArrayList <Post> arraylistPostByCategory;
    View footerProgressBar;
    boolean isLoading = false;
    boolean limitdata = false;
    mHandler mHandler ;
    int category_id =0;
    int page = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_by_category);

        // Nạp dữ liệu cho view
        tbarPostByCategory = findViewById(R.id.tbar_post_by_category);
        listViewPostByCategory = findViewById(R.id.listview_post_by_category);
        arraylistPostByCategory = new ArrayList<>();
        postByCategoryAdapter = new PostByCategoryAdapter(getApplicationContext(),arraylistPostByCategory);
        listViewPostByCategory.setAdapter(postByCategoryAdapter);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        footerProgressBar = inflater.inflate(R.layout.progress_bar,null);
        mHandler = new mHandler();
        tbarPostByCategory.setTitle(getIntent().getStringExtra("category_title"));

        //Bắt sự kiện
        ActionToolbar();
        getCategory_id();
        getData_postByCategory(page);
        LoadMoreData();
    }

    private void getCategory_id() {
        category_id = getIntent().getIntExtra("category_id",-1);
        Log.d("category_id",category_id+"");
    }

    private void LoadMoreData() {
        listViewPostByCategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),PostDetailActivity.class);
                intent.putExtra("info",arraylistPostByCategory.get(i));
                startActivity(intent);
            }
        });
        listViewPostByCategory.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int i) {

            }

            @Override
            public void onScroll(AbsListView absListView, int FirstItem, int VisibleItem, int TotalItem) {
                if((FirstItem + VisibleItem == TotalItem)&& TotalItem !=0 && isLoading == false && limitdata==false)
                {
                    isLoading = true;
                    ThreadData threadData = new ThreadData();
                    threadData.start();
                }
            }
        });
    }

    private void getData_postByCategory(int Page) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        String url = Server.url_postBycategory + (Page+"");
        Log.d("url",url);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                int post_id = 0;
                int user_id =0;
                String post_title ="";
                int post_price =0;
                int cate_id = 0;
                String post_describe = "";
                String post_contact = "";
                String post_image = "";
                Log.d("response",response);

                if (response!= null && response.length()> 2)
                {
                    listViewPostByCategory.removeFooterView(footerProgressBar);
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        for(int i =0;i<jsonArray.length();i++)
                        {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            post_id = jsonObject.getInt("post_id");
                            user_id = jsonObject.getInt("user_id");
                            post_title = jsonObject.getString("post_title");
                            post_price =jsonObject.getInt("post_price");
                            cate_id = jsonObject.getInt("category_id");
                            post_describe = jsonObject.getString("post_descripe");
                            post_contact = jsonObject.getString("post_contact");
                            post_image = jsonObject.getString("post_image");

                            arraylistPostByCategory.add(new Post(post_id,user_id,cate_id,post_title,post_price,post_describe,post_contact,post_image));
                            postByCategoryAdapter.notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else
                {
                    limitdata = true;
                    listViewPostByCategory.removeFooterView(footerProgressBar);
                    Toast.makeText(PostByCategoryActivity.this, "Đã hiển thị tất cả kết quả", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PostByCategoryActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<String,String>();
                param.put("category_id",String.valueOf(category_id));
                return param;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void ActionToolbar() {
        setSupportActionBar(tbarPostByCategory);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tbarPostByCategory.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public class mHandler extends Handler
    {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what)
            {
                case 0:
                    listViewPostByCategory.addFooterView(footerProgressBar);
                    break;
                case 1:
                    getData_postByCategory(++page);
                    isLoading = false;
                    break;
            }
            super.handleMessage(msg);
        }
    }

    public class ThreadData extends Thread{
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message = mHandler.obtainMessage(1);
            mHandler.sendMessage(message);
            super.run();
        }
    }
}
