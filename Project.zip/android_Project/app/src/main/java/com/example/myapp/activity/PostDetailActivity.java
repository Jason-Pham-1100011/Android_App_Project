package com.example.myapp.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapp.R;
import com.example.myapp.model.Post;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostDetailActivity extends AppCompatActivity {

    Toolbar toolbar_postDeatil;
    ImageView img_postDetail;
    TextView txt_posDetail_title;
    TextView txt_postDetail_price;
    TextView getTxt_posDetail_descripe,txt_postDetail_contact,txt_postDetail_username;
    CircleImageView avt_postDetail_username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);

        //
        toolbar_postDeatil = findViewById(R.id.toolbar_postDetail);
        img_postDetail = findViewById(R.id.imgView_postDetail);
        txt_posDetail_title = findViewById(R.id.textView_postDetail_title);
        txt_postDetail_price = findViewById(R.id.textView_postDetail_price);
        getTxt_posDetail_descripe = findViewById(R.id.textView_postDetail_describe);
        txt_postDetail_contact = findViewById(R.id.txt_postDetail_contact);
        txt_postDetail_username = findViewById(R.id.txt_postDetail_username);
        avt_postDetail_username = findViewById(R.id.avt_postDetail_user);

        //
        actionToolBar();
        getInformation();
    }

    private void getInformation() {
        int id = 0;
        int user_postDtail_id = 0;
        String post_title = "";
        int post_price =0;
        String post_Descripe ="";
        String post_image ="";
        String post_contact="";

        Post post = (Post) getIntent().getSerializableExtra("info");
        id = post.getId();
        user_postDtail_id = post.getUser_id();
        post_title = post.getPost_name();
        post_price = post.getPost_info_price();
        post_Descripe = post.getPost_info_describe();
        post_contact = post.getPost_contact();
        post_image = post.getPost_image();

        Log.d("des",post_Descripe);
        txt_posDetail_title.setText(post_title);
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        txt_postDetail_price.setText(decimalFormat.format(post_price));
        getTxt_posDetail_descripe.setText(post_Descripe);
        txt_postDetail_contact.setText("Điện thoại: "+ post_contact);
        Picasso.with(getApplicationContext()).load(post_image)
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.noimage)
                .into(img_postDetail);
    }

    private void actionToolBar() {
        setSupportActionBar(toolbar_postDeatil);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar_postDeatil.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
