package com.example.myapp.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.ToolbarWidgetWrapper;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.R;
import com.example.myapp.adapter.PostByCategoryAdapter;
import com.example.myapp.model.Post;
import com.example.myapp.util.Server;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.Inflater;

public class SearchActivity extends AppCompatActivity {

    MaterialSearchView searchView ;
    Toolbar toolbar;
    boolean isLoading = false;
    boolean limitdata = false;
    mHandler mHandler ;
    int page = 1;
    String search_key;
    ListView listViewPostBySearch;
    PostByCategoryAdapter postBySearchAdapter;
    ArrayList<Post> arraylistPostBySearch;
    View footerProgressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        toolbar = (Toolbar) findViewById(R.id.toolbar_search);
        listViewPostBySearch = findViewById(R.id.listview_post_by_search);
        arraylistPostBySearch = new ArrayList<>();
        postBySearchAdapter = new PostByCategoryAdapter(getApplicationContext(),arraylistPostBySearch);
        listViewPostBySearch.setAdapter(postBySearchAdapter);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        footerProgressBar = inflater.inflate(R.layout.progress_bar,null);
        mHandler = new mHandler();
        //
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Tìm kiếm");
        toolbar.setTitleTextColor(Color.parseColor("#ffffff"));
        LoadMoreData();
        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                search_key = query;
                page = 1;
                arraylistPostBySearch.clear();
                getData_postBySearch(page);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        listViewPostBySearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),PostDetailActivity.class);
                intent.putExtra("info",arraylistPostBySearch.get(i));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);

        MenuItem item = menu.findItem(R.id.search);
        searchView.setMenuItem(item);
        return true;
    }

    private void LoadMoreData() {

        listViewPostBySearch.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView absListView, int i) {

            }

            @Override
            public void onScroll(AbsListView absListView, int FirstItem, int VisibleItem, int TotalItem) {
                if((FirstItem + VisibleItem == TotalItem)&& TotalItem !=0 && isLoading == false && limitdata==false)
                {
                    isLoading = true;
                    SearchActivity.ThreadData threadData = new SearchActivity.ThreadData();
                    threadData.start();
                }
            }
        });
    }

    private void getData_postBySearch(int Page) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        String url = Server.url_postBySearch + (Page+"");
        Log.d("url",url);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                int post_id = 0;
                int user_id =0;
                String post_title ="";
                int post_price =0;
                int cate_id = 0;
                String post_describe = "";
                String post_contact = "";
                String post_image = "";
                Log.d("response",response);

                if (response!= null && response.length()> 2)
                {
                    listViewPostBySearch.removeFooterView(footerProgressBar);
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        for(int i =0;i<jsonArray.length();i++)
                        {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            post_id = jsonObject.getInt("post_id");
                            user_id = jsonObject.getInt("user_id");
                            post_title = jsonObject.getString("post_title");
                            post_price =jsonObject.getInt("post_price");
                            cate_id = jsonObject.getInt("category_id");
                            post_describe = jsonObject.getString("post_descripe");
                            post_contact = jsonObject.getString("post_contact");
                            post_image = jsonObject.getString("post_image");
                            Log.d("searchtitle",post_title);
                            arraylistPostBySearch.add(new Post(post_id,user_id,cate_id,post_title,post_price,post_describe,post_contact,post_image));
                            postBySearchAdapter.notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else
                {
                    limitdata = true;
                    listViewPostBySearch.removeFooterView(footerProgressBar);
                    Toast.makeText(SearchActivity.this, "Đã duyệt hết kết quả", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(SearchActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<String,String>();
                param.put("search_key",search_key);
                Log.d("search_key",search_key);
                return param;
            }
        };
        requestQueue.add(stringRequest);
    }

    public class mHandler extends Handler
    {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what)
            {
                case 0:
                    listViewPostBySearch.addFooterView(footerProgressBar);
                    break;
                case 1:
                    getData_postBySearch(++page);
                    isLoading = false;
                    break;
            }
            super.handleMessage(msg);
        }
    }

    public class ThreadData extends Thread{
        @Override
        public void run() {
            mHandler.sendEmptyMessage(0);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message = mHandler.obtainMessage(1);
            mHandler.sendMessage(message);
            super.run();
        }
    }
}
