package com.example.myapp.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapp.R;
import com.example.myapp.util.Retrofit2.APIUtils;
import com.example.myapp.util.Retrofit2.DataClient;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpActivity extends AppCompatActivity {
    CircleImageView imgSignUpAvatar;
    TextInputEditText edtUsername,edtPassword,edtPhone,edtEmail;
    Button btnSignUpSubmit,btnSignUpCancel;
    int Request_Code_SignUp_Image = 123;
    String realpath = "";
    String username,password,email,phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Nạp view cho các biến
        initView();

        //Bắt sự kiện cho view
        imgSignUpAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                askPermissionAndReadFile();
            }
        });
        btnSignUpSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = edtUsername.getText().toString();
                password = edtPassword.getText().toString();
                phone = edtPhone.getText().toString();
                email = edtEmail.getText().toString();

                if(realpath.length() > 0)
                {
                    if (username.length()>0 && password.length()>0 && phone.length()>0 && email.length() > 0)
                    {
                        File file = new File (realpath);
                        String file_path = file.getAbsolutePath();
                        String[] arrayFileName = file_path.split("\\.");

                        file_path = arrayFileName[0]+ System.currentTimeMillis() +"."+arrayFileName[1];
//                Log.d("url",file_path);
                        RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"),file);

                        MultipartBody.Part body = MultipartBody.Part.createFormData("uploaded_file",file_path,requestBody);

                        DataClient dataClient = APIUtils.getData();
                        retrofit2.Call <String> callback = dataClient.UploadAvt(body);
                        callback.enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                if(response != null)
                                {
                                    String message = response.body();
//                            Log.d("urlImage",message);
                                    if(message.length()>0)
                                    {
                                        DataClient insertSignUp = APIUtils.getData();
                                        retrofit2.Call<String> callback = insertSignUp.InsertSingUp(username,password,email,phone,APIUtils.Base_Url +"avatar/"+message);
                                        callback.enqueue(new Callback<String>() {
                                            @Override
                                            public void onResponse(Call<String> call, Response<String> response) {
                                                String result = response.body();
                                                Log.d("result",result);
                                                if (result.equals("Success"))
                                                {
                                                    Toast.makeText(SignUpActivity.this, "Đăng thành công", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }
                                            }

                                            @Override
                                            public void onFailure(Call<String> call, Throwable t) {

                                            }
                                        });
                                    }
                                }
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {
                                Log.d("erroAddPost",t.getMessage());
                            }
                        });
                    }
                    else{
                        Toast.makeText(SignUpActivity.this, "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    if (username.length()>0 && password.length()>0 && phone.length()>0 && email.length() > 0)
                    {
                        DataClient insertSignUp = APIUtils.getData();
                        retrofit2.Call<String> callback = insertSignUp.InsertSingUp(username,password,email,phone,null);
                        callback.enqueue(new Callback<String>() {
                            @Override
                            public void onResponse(Call<String> call, Response<String> response) {
                                String result = response.body();
                                Log.d("result",result);
                                if (result.equals("Success"))
                                {
                                    Toast.makeText(SignUpActivity.this, "Đăng thành công", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            }

                            @Override
                            public void onFailure(Call<String> call, Throwable t) {

                            }
                        });
                    }
                    else
                        {
                            Toast.makeText(SignUpActivity.this, "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                        }
                }
            }
        });

        btnSignUpCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == Request_Code_SignUp_Image && resultCode == RESULT_OK && data!=null)
        {
            Uri uri = data.getData();
            realpath = getRealPathFromURI(uri);
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgSignUpAvatar.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void initView() {
        imgSignUpAvatar = findViewById(R.id.img_signup_avt);
        edtUsername = findViewById(R.id.edt_signup_username);
        edtPassword = findViewById(R.id.edt_signup_password);
        edtPhone = findViewById(R.id.edt_signup_phone);
        edtEmail = findViewById(R.id.edt_signup_email);
        btnSignUpSubmit = findViewById(R.id.btn_signup_submit);
        btnSignUpCancel = findViewById(R.id.btn_signup_cancel);
    }

    public String getRealPathFromURI (Uri contentUri) {
        String path = null;
        String[] proj = { MediaStore.MediaColumns.DATA };
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            path = cursor.getString(column_index);
        }
        cursor.close();
        return path;
    }

    public  boolean isStoragePermissionGranted(int requestId, String permissionName) {
        if (android.os.Build.VERSION.SDK_INT >= 23) {

            // Kiểm tra quyền
            int permission = ActivityCompat.checkSelfPermission(this, permissionName);


            if (permission != PackageManager.PERMISSION_GRANTED) {

                // Nếu không có quyền, cần nhắc người dùng cho phép.
                this.requestPermissions(
                        new String[]{permissionName},
                        requestId
                );
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && requestCode == Request_Code_SignUp_Image){
            readFile();
            Log.v("ISPERMISSION","Permission: "+permissions[0]+ "was "+grantResults[0]);
            //resume tasks needing this permission
        }
    }

    private void askPermissionAndReadFile() {
        boolean canRead = this.isStoragePermissionGranted(Request_Code_SignUp_Image,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        //
        if (canRead) {
            this.readFile();
        }
    }

    private void readFile() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,Request_Code_SignUp_Image);
    }
}
