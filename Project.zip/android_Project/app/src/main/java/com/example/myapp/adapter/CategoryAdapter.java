package com.example.myapp.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapp.R;
import com.example.myapp.model.Category;

import java.util.ArrayList;

public class CategoryAdapter extends BaseAdapter {
    ArrayList <Category> arraylistCategory;
    Context context;

    public CategoryAdapter(ArrayList<Category> arraylistCategory, Context context) {
        this.arraylistCategory = arraylistCategory;
        this.context = context;
    }

    @Override
    public int getCount() {
        return arraylistCategory.size();
    }

    @Override
    public Object getItem(int i) {
        return arraylistCategory.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }


    /*
    Sử dụng class ViewHolder để giữ lại giá trị view đã load lần đầu
    những lần sau sẽ không cần load lại từ đầu
    */
    public class ViewHolder{
        TextView txt_category_title;
        ImageView img_category;
    }

    /*
    Nạp giá trị cho view của ListView Category
    */
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if(view == null)
        {
            //Nếu view load lần đầu sẽ rỗng, nạp giá trị cho view từ định dạng đã định nghĩa ở file xml
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.listview_category,null);

            // Thực hiện gán các giá trị của view cho viewHolder
            viewHolder.txt_category_title = (TextView) view.findViewById(R.id.textView_ategory_title);
            viewHolder.img_category = (ImageView) view.findViewById(R.id.ImgV_category);
            view.setTag(viewHolder);

        }else{
            //Nếu load từ lần 2 trở đi, chỉ cần cập nhật lại giá trị cho viewHolder
            viewHolder = (ViewHolder) view.getTag();

        }

        //Gán các giá trị dữ liệu vào view
        Category category = (Category) getItem(i);
        viewHolder.txt_category_title.setText(category.getCategory_title());
        int imageId = this.getMipmapResIdByName(category.getCategory_image());
        viewHolder.img_category.setImageResource(imageId);
        return view;
    }

    //Lấy vị trí hình ảnh theo tên
    public int getMipmapResIdByName(String resName) {
        String pkgName = context.getPackageName();

        // not find --> 0
        int resID = context.getResources().getIdentifier(resName,"mipmap",pkgName);

        return resID;
    }
}
