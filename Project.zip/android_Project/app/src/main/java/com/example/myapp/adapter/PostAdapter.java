package com.example.myapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapp.R;
import com.example.myapp.activity.PostDetailActivity;
import com.example.myapp.model.Post;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ItemHolder> {
    Context context;
    ArrayList<Post> arraylistPost;

    public PostAdapter(Context context, ArrayList<Post> arraylistPost) {
        this.context = context;
        this.arraylistPost = arraylistPost;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_post,null);
        ItemHolder itemHolder = new ItemHolder(view);
        return itemHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
        Post post = arraylistPost.get(position);
        holder.post_title.setText(post.getPost_name());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        holder.post_price.setText("Giá: " + decimalFormat.format(post.getPost_info_price()) + "vnd");
        Picasso.with(context).load(post.getPost_image())
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.noimage)
                .into(holder.post_img);
    }



    @Override
    public int getItemCount() {
        return arraylistPost.size();
    }

    public class ItemHolder extends RecyclerView.ViewHolder
    {
        public ImageView post_img;
        public TextView post_title,post_price;

        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            post_img = itemView.findViewById(R.id.imgView_post);
            post_title = itemView.findViewById(R.id.txt_post_tilte);
            post_price = itemView.findViewById(R.id.txt_post_price);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, PostDetailActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    Toast.makeText(context, arraylistPost.get(getPosition()).getPost_name(), Toast.LENGTH_SHORT).show();
                    intent.putExtra("info", arraylistPost.get(getPosition()));
                    context.startActivity(intent);

                }
            });
        }
    }

}
