package com.example.myapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapp.R;
import com.example.myapp.model.Post;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class PostByCategoryAdapter extends BaseAdapter {
    Context context;
    ArrayList<Post> arraylistPostByCategory;

    public PostByCategoryAdapter(Context context, ArrayList<Post> arraylistPostByCategory) {
        this.context = context;
        this.arraylistPostByCategory = arraylistPostByCategory;
    }

    @Override
    public int getCount() {
        return arraylistPostByCategory.size();
    }

    @Override
    public Object getItem(int i) {
        return arraylistPostByCategory.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public class ViewHolder{
        public TextView txtPostbyCategoryTitle, txtPostbyCategoryPrice;
        public ImageView PostbyCategoryImage;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if(view ==null)
        {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.listview_row_post_by_category,null);
            viewHolder.txtPostbyCategoryTitle = (TextView) view.findViewById(R.id.txt_postbycategory_title);
            viewHolder.txtPostbyCategoryPrice = (TextView) view.findViewById(R.id.txt_postbycategory_price);
            viewHolder.PostbyCategoryImage = (ImageView) view.findViewById(R.id.imageview_postbycategory_img);
            view.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) view.getTag();
        }

        Post post = (Post) getItem(i);
        viewHolder.txtPostbyCategoryTitle.setText(post.getPost_name());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        viewHolder.txtPostbyCategoryPrice.setText("Giá: " + decimalFormat.format(post.getPost_info_price()) + "vnd");
        Picasso.with(context).load(post.getPost_image())
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.noimage)
                .into(viewHolder.PostbyCategoryImage);
        return view;
    }
}
