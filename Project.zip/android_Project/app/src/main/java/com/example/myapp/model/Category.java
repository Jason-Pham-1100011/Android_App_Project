package com.example.myapp.model;

public class Category {
    public  int id;
    public String category_title;
    public String category_image;

    public Category(int id, String category_title, String category_image) {
        this.id = id;
        this.category_title = category_title;
        this.category_image = category_image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory_title() {
        return category_title;
    }

    public void setCategory_title(String category_title) {
        this.category_title = category_title;
    }

    public String getCategory_image() {
        return category_image;
    }

    public void setCategory_image(String category_image) {
        this.category_image = category_image;
    }
}
