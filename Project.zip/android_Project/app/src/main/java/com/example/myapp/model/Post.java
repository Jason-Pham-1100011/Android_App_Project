package com.example.myapp.model;

import java.io.Serializable;

public class Post implements Serializable {
    public int id,user_id,category_id;
    public String post_name;
    public Integer post_info_price;
    public String post_info_describe;
    public String post_contact;
    public String post_image;

    public Post(int id, int user_id, int category_id, String post_name, Integer post_info_price, String post_info_describe, String post_contact, String post_image) {
        this.id = id;
        this.user_id = user_id;
        this.category_id = category_id;
        this.post_name = post_name;
        this.post_info_price = post_info_price;
        this.post_info_describe = post_info_describe;
        this.post_contact = post_contact;
        this.post_image = post_image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getPost_name() {
        return post_name;
    }

    public void setPost_name(String post_name) {
        this.post_name = post_name;
    }

    public Integer getPost_info_price() {
        return post_info_price;
    }

    public void setPost_info_price(Integer post_info_price) {
        this.post_info_price = post_info_price;
    }

    public String getPost_info_describe() {
        return post_info_describe;
    }

    public void setPost_info_describe(String post_info_describe) {
        this.post_info_describe = post_info_describe;
    }

    public String getPost_contact() {
        return post_contact;
    }

    public void setPost_contact(String post_contact) {
        this.post_contact = post_contact;
    }

    public String getPost_image() {
        return post_image;
    }

    public void setPost_image(String post_image) {
        this.post_image = post_image;
    }









}
