package com.example.myapp.util.Retrofit2;

public class APIUtils {
    public static final String Base_Url = "http://192.168.2.144:8888/AndroidProjectServer/";

    //Hàm cầu nối yêu cầu gửi và nhận dữ liệu vào DataClient class
    public static DataClient getData()
    {
        return RetrofitClient.getClient(Base_Url).create(DataClient.class);
    }
}
