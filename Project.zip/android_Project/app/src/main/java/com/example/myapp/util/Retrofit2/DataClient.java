package com.example.myapp.util.Retrofit2;

import com.example.myapp.model.User;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface DataClient {

    @Multipart
    @POST("uploadAvatar.php")
    Call <String> UploadAvt(@Part MultipartBody.Part avt);

    @FormUrlEncoded
    @POST("insert.php")
    Call <String> InsertSingUp(@Field("username") String username
                                ,@Field("password") String password
                                ,@Field("email") String email
                                ,@Field("phone") String phone
                                ,@Field("user_image") String user_image);

    @FormUrlEncoded
    @POST("login.php")
    Call <List<User>> Logindata(@Field("username") String username
                                ,@Field("password") String password);

    @Multipart
    @POST("uploadImagePost.php")
    Call <String> UploadImagePost(@Part MultipartBody.Part ImagePost);

    @FormUrlEncoded
    @POST("insertPost.php")
    Call <String> InsertPost( @Field("user_id") int user_id
                                ,@Field("category_id") int category_id
                                ,@Field("post_title") String post_title
                                ,@Field("post_price") int post_price
                                ,@Field("post_descripe") String post_descripe
                                ,@Field("post_contact") String post_contact
                                ,@Field("post_image") String post_image);
}
