package com.example.myapp.util;

public class Server {

    public static String localhost = "192.168.2.144:8888";
    public static String url_category = "http://" + localhost +"/AndroidProjectServer/get_category.php";
    public static String url_post = "http://" + localhost +"/AndroidProjectServer/get_newpost.php";
    public static String url_postBycategory = "http://" + localhost +"/AndroidProjectServer/get_post.php?page=";
    public static String url_postBySearch = "http://" + localhost +"/AndroidProjectServer/get_postBySearch.php?page=";
}
