-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2020 at 03:50 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ineed`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_title` varchar(200) NOT NULL,
  `category_image` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_title`, `category_image`) VALUES
(1, 'Sách', 'book'),
(2, 'Quần áo', 'clothes'),
(3, 'Khác', 'more');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `post_title` varchar(1024) NOT NULL,
  `post_price` int(11) NOT NULL,
  `post_descripe` varchar(2048) NOT NULL,
  `post_contact` varchar(2048) NOT NULL,
  `post_image` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `user_id`, `category_id`, `post_title`, `post_price`, `post_descripe`, `post_contact`, `post_image`) VALUES
(1, 1, 1, 'Clean Code Book Old', 200000, 'Cần bán lại sách cũ', '0903629', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/sach.jpg'),
(2, 2, 2, 'nice Jacket', 250000, 'Mình cần bán lại áo khoác cũ!', '0902223', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/jacket.jpg'),
(3, 1, 1, 'Clean Code Book New', 200000, 'Cần bán lại sách cũ!', '033256', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/sach.jpg'),
(4, 2, 2, 'Ao Khoac', 250000, 'Mình cần bán lại áo khoác cũ', '036210', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/jacket.jpg'),
(5, 0, 3, 'Moto Bike', 75000000, 'Cần bán xe cũ', '020136', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/xe.jpg'),
(6, 3, 3, 'Xe CB 150cc', 50000000, ' xe cũ giá rẽ', '022112', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/xe.jpg'),
(7, 7, 3, 'dien thoai cu', 123456, 'minh can ban dien thoai cu', '0122469', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/IMG_20191201_1807031575208356658.jpg'),
(8, 7, 2, 'old dress', 2000000, 'i need sell my old dress', '0933251', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/IMG_20191201_1807031575208648423.jpg'),
(9, 7, 1, 'Sach moi', 50000, 'Minh co sach moi mua can ban', '022222', 'http://192.168.1.5:8888/AndroidProjectServer/imagePost/Neuchiconmotngaydesong.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `user_image` varchar(1024) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `email`, `phone`, `user_image`) VALUES
(1, 'user1', '123456', 'user1@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(1).jpg'),
(2, 'user2', '123456', 'user2@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(2).jpg'),
(3, 'user3', '123456', 'user3@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(3).jpg'),
(4, 'user4', '123456', 'user4@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(4).jpg'),
(5, 'user5', '123456', 'user5@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(5).jpg'),
(6, 'user6', '123456', 'user6@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(6).jpg'),
(7, 'haha', '123456', 'haha@gmail.com', '123456', 'http://192.168.1.5:8888/AndroidProjectServer/avatar/avt(3).jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
